rm svn.aux svn.toc svn.nav svn.out *.bib svn.snm svn.log *.blg
